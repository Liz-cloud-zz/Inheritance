public  class Pizza extends Menu{

   private String base;
   private String extra_cheese;
   private String extra_garlic;
      
   public Pizza(String number, String s, String base , String extra_cheese, String extra_garlic){
      super(number, s);
      this.base=base;
      this.extra_cheese=extra_cheese;
      this.extra_garlic=extra_garlic;
   }
   
   public String getNumber(){
         return (super.getNumber());
         
   }
   
   public String toString(){
   
      return ("Pizza: "+ super.toString() +", "+ this.base+ ", "+this.extra_cheese+", "+ this.extra_garlic);
   }
}   
   
       
