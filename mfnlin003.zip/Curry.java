public class Curry extends Menu{
   private String curry_type;
   
      
   public Curry(String number, String s, String curry_type){
      super(number, s);
      this.curry_type=curry_type;
   }
   public String getNumber(){
         return (super.getNumber());
         
   }
   
   public String toString(){
   
      return ("Curry: "+ super.toString() + ", "+this.curry_type);
   }
}
   
               
  
