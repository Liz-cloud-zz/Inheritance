import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;
import java.util.*;

public class Question2{
   public static void  main(String  []args){
      Scanner keyboard = new Scanner(System.in);
      String s;
      String i;
      Menu m;
      Pizza p;
      Curry c;
      SoftDrink sd;
      List l= new ArrayList();
      System.out.println("Welcome to Great International Food Court" );
      System.out.println("MENU: add (P)izza, add (C)urry, add (S)oft drink, (D)elete, (L)ist, (Q)uit");
      String input=keyboard.next();
      while(! input.equals("q")){
         if(input.equals("p")){
            System .out.println("Enter the menu item number" );
            i=keyboard.next();
            System.out.println("Enter the size");
            s=keyboard.next();
            m= new Menu(i,s);
            System.out.println("Enter the base");
            String b=keyboard.next();
            System.out.println("Enter extra cheese");
            String ch=keyboard.next();
            System.out.println("Enter extra garlic");
            String g= keyboard.next();
            p=new Pizza(i,s,b,ch,g);
            l.add(p);
            System.out.println("Done");
            
         }
         else if (input.equals("c")){
            System .out.println("Enter the menu item number" );
            i=keyboard.next();
            System.out.println("Enter the size");
            s=keyboard.next();
            m= new Menu(i,s);
            System.out.println("Enter the curry type");
            String currytype=keyboard.next();
            c=new Curry(i,s,currytype);
            l.add(c);
            System.out.println("Done");
         
         }  
         else if (input.equals("s")){
            System .out.println("Enter the menu item number" );
            i=keyboard.next();
            System.out.println("Enter the size");
            s=keyboard.next();
            m= new Menu(i,s);
            System.out.println("Enter the flavour");
            String flavor=keyboard.next();
            System.out.println("Enter whether it is a bottle or can");
            String con= keyboard.next();
            sd=new SoftDrink(i,s,flavor,con);
            l.add(sd);
            System.out.println("Done");
         } 
         else if(input.equals("d")){
            System .out.println("Enter the menu item number" );
            i=keyboard.next();
            boolean found= false ;
            for (int index=0 ; index< l.size(); index++){
               Menu kb = (Menu) l.get(index);
               if (kb.getNumber().equals(i)){
                  found=true;
                  l.remove(index);
               }       
            }
            if (found==false){
               System.out.println("Not found");
            }
            else{
               System.out.println("Done");
            }      
         }
         else if (input.equals("l")){
            for (int index =0 ; index< l.size() ; index++){
                     
               System.out.println((l.get(index)).toString());
            }
            System.out.println("Done");
         }
         
         System.out.println("MENU: add (P)izza, add (C)urry, add (S)oft drink, (D)elete, (L)ist, (Q)uit");
         input=keyboard.next();      
      }
      
   }
    
}