
public class Rectangle extends VectorObject{
   private int x_length;
   private int y_length;
   public Rectangle(int id, int x,int y, int x1, int y1){
      super(id,x,y);
      this.x_length=x1;
      this.y_length=y1;
         
   }

        
   public void  draw(char [][] matrix){
        //matrix = new char[x_length][y_length];
        for (int i=0; i < y_length ; i++){
            for(int i1= 0 ; i1< x_length; i1++){
             matrix[i+y][i1+x] = '*';
            }
            
        }
       
   }
 
                           
                     
                           
   
}