import java.util.List;

public class Menu {
   public String menuitem_number;
   private String size;
   
   public Menu(String menuitem_number, String size){
     
      this.menuitem_number=menuitem_number;
      this.size=size;
   }
   public String getNumber(){
         return(this.menuitem_number);
   }      
   
   public String toString(){
      return (this.menuitem_number+", "+ this.size);
   }
   
  

}