public class Plane extends Vehicle{
   
   private String manufacturer;
   private int model_number;
   public Plane(String color, int numPassengers, String manufacturer,int model_number ){
   
      super(numPassengers, color);
      this.model_number= model_number;
      this.manufacturer= manufacturer;
   }
   
   public String toString(){
   
      return(super.toString()+" "+ this.manufacturer +" "+ this.model_number );
   }   
  
}