
public class VLine extends VectorObject{
   private int y_length;
   public VLine(int id, int x,int y, int y1){
      super(id,x,y);
      this.y_length=y1;
         
   }
   public void  draw(char [][] matrix){
           for (int i=0; i < y_length ; i++){
             matrix[y+i][x] = '*';
            }
            
        
   }
}