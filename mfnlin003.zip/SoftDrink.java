public class SoftDrink extends Menu{
   private String size;
   private String flavour;
   private String container;
   
      
   public SoftDrink(String number, String s, String flavour, String container){
      super(number, s);
      this.flavour= flavour;
      this.container= container;
   }
   
   public String getNumber(){
         return (super.getNumber());
         
   }   
   public String toString(){
   
      return ("Soft Drink: "+ super.toString() +", "+ this.flavour+ ", "+this.container);
   }
         
}