public class Car extends Vehicle{

   private  int additional_doors;
   
   public Car( String color,int numPassengers, int additional_doors){
   
      super(numPassengers, color);
      this.additional_doors= additional_doors; 
   }
   public String toString(){
      return(super.toString()+ " "+this.additional_doors+" doors");
   }   
  
}