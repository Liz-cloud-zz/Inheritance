
import java.lang.Math;
public class PtLine extends VectorObject{
   private int x1;
   private int y1;
   public PtLine(int id, int x,int y,int y1 ,int x1){
      super(id,x,y);
      this.x1=x1;
      this.y1=y1;
      
         
   }

   
   public void draw(char [][]matrix){
   
      int intial_y=this.y;
      int intial_x=this.x;
      int final_y=this.y1;
      int final_x=this.x1;
   
      double m;
      double error;
      int ys;
      int temp1;
      int temp2;
      int v;
      boolean steep=Math.abs(final_y-intial_y)>Math.abs(final_x-intial_x);
      if(steep){
         temp1=intial_x;
         intial_x=intial_y;
         intial_y=temp1;
         
         temp2=final_x;
         final_x=final_y;
         final_y=temp2;
         
      }
      if(intial_x>final_x){
         temp1=intial_x;
         intial_x=final_x;
         final_x=temp1;
         
         temp2=intial_y;
         intial_y= final_y;
         intial_y=temp2;
      }
      int sx=final_x-intial_x;
      int sy=final_y-intial_y;
      if(sx!=0){
         
         m=(Math.abs(sy))/(double)(sx);
         v=intial_y;
         error=0;
         if(intial_y<final_y){
            ys=1; 
         }
         else{
            ys=-1;
               
         }
      
      
         for(int i=intial_x; i<=final_x;i++){
            if(steep){
               matrix[i][v] = '*';
            }
            else{
               matrix[v][i]='*';
            }
            error=error+m;
            if(error>0.5){
               v=v+ys;
               error=error-1;
            }   
         }  
      }       
        
      else{
      
         for (int i=0; i<= (x-y1); i++){
            
            matrix[intial_y+i][intial_x-i]='*';
         }
      }     
   
        
   }
}
